﻿namespace Library_MS
{
    partial class AddBook
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtLan = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.txtLen = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.txtDate = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.txtDesc = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.txtAuthor = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.txtTitle = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel2 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel3 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel4 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel5 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel6 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuFlatButton1 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.SuspendLayout();
            // 
            // txtLan
            // 
            this.txtLan.BorderColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(237)))), ((int)(((byte)(59)))));
            this.txtLan.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtLan.BorderColorMouseHover = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(237)))), ((int)(((byte)(59)))));
            this.txtLan.BorderThickness = 3;
            this.txtLan.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtLan.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtLan.ForeColor = System.Drawing.Color.White;
            this.txtLan.isPassword = false;
            this.txtLan.Location = new System.Drawing.Point(193, 351);
            this.txtLan.Margin = new System.Windows.Forms.Padding(4);
            this.txtLan.Name = "txtLan";
            this.txtLan.Size = new System.Drawing.Size(181, 44);
            this.txtLan.TabIndex = 5;
            this.txtLan.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtLen
            // 
            this.txtLen.BorderColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(237)))), ((int)(((byte)(59)))));
            this.txtLen.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtLen.BorderColorMouseHover = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(237)))), ((int)(((byte)(59)))));
            this.txtLen.BorderThickness = 3;
            this.txtLen.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtLen.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtLen.ForeColor = System.Drawing.Color.White;
            this.txtLen.isPassword = false;
            this.txtLen.Location = new System.Drawing.Point(4, 351);
            this.txtLen.Margin = new System.Windows.Forms.Padding(4);
            this.txtLen.Name = "txtLen";
            this.txtLen.Size = new System.Drawing.Size(181, 44);
            this.txtLen.TabIndex = 4;
            this.txtLen.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtDate
            // 
            this.txtDate.BorderColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(237)))), ((int)(((byte)(59)))));
            this.txtDate.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtDate.BorderColorMouseHover = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(237)))), ((int)(((byte)(59)))));
            this.txtDate.BorderThickness = 3;
            this.txtDate.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtDate.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtDate.ForeColor = System.Drawing.Color.White;
            this.txtDate.isPassword = false;
            this.txtDate.Location = new System.Drawing.Point(4, 272);
            this.txtDate.Margin = new System.Windows.Forms.Padding(4);
            this.txtDate.Name = "txtDate";
            this.txtDate.Size = new System.Drawing.Size(370, 44);
            this.txtDate.TabIndex = 3;
            this.txtDate.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtDesc
            // 
            this.txtDesc.BorderColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(237)))), ((int)(((byte)(59)))));
            this.txtDesc.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtDesc.BorderColorMouseHover = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(237)))), ((int)(((byte)(59)))));
            this.txtDesc.BorderThickness = 3;
            this.txtDesc.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtDesc.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtDesc.ForeColor = System.Drawing.Color.White;
            this.txtDesc.isPassword = false;
            this.txtDesc.Location = new System.Drawing.Point(4, 193);
            this.txtDesc.Margin = new System.Windows.Forms.Padding(4);
            this.txtDesc.Name = "txtDesc";
            this.txtDesc.Size = new System.Drawing.Size(370, 44);
            this.txtDesc.TabIndex = 2;
            this.txtDesc.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtAuthor
            // 
            this.txtAuthor.BorderColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(237)))), ((int)(((byte)(59)))));
            this.txtAuthor.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtAuthor.BorderColorMouseHover = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(237)))), ((int)(((byte)(59)))));
            this.txtAuthor.BorderThickness = 3;
            this.txtAuthor.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtAuthor.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtAuthor.ForeColor = System.Drawing.Color.White;
            this.txtAuthor.isPassword = false;
            this.txtAuthor.Location = new System.Drawing.Point(4, 114);
            this.txtAuthor.Margin = new System.Windows.Forms.Padding(4);
            this.txtAuthor.Name = "txtAuthor";
            this.txtAuthor.Size = new System.Drawing.Size(370, 44);
            this.txtAuthor.TabIndex = 1;
            this.txtAuthor.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtTitle
            // 
            this.txtTitle.BorderColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(237)))), ((int)(((byte)(59)))));
            this.txtTitle.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtTitle.BorderColorMouseHover = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(237)))), ((int)(((byte)(59)))));
            this.txtTitle.BorderThickness = 3;
            this.txtTitle.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtTitle.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtTitle.ForeColor = System.Drawing.Color.White;
            this.txtTitle.isPassword = false;
            this.txtTitle.Location = new System.Drawing.Point(4, 35);
            this.txtTitle.Margin = new System.Windows.Forms.Padding(4);
            this.txtTitle.Name = "txtTitle";
            this.txtTitle.Size = new System.Drawing.Size(370, 44);
            this.txtTitle.TabIndex = 0;
            this.txtTitle.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.bunifuCustomLabel1.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(4, 11);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(73, 16);
            this.bunifuCustomLabel1.TabIndex = 6;
            this.bunifuCustomLabel1.Text = "Book Title";
            // 
            // bunifuCustomLabel2
            // 
            this.bunifuCustomLabel2.AutoSize = true;
            this.bunifuCustomLabel2.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.bunifuCustomLabel2.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel2.Location = new System.Drawing.Point(4, 90);
            this.bunifuCustomLabel2.Name = "bunifuCustomLabel2";
            this.bunifuCustomLabel2.Size = new System.Drawing.Size(88, 16);
            this.bunifuCustomLabel2.TabIndex = 7;
            this.bunifuCustomLabel2.Text = "Book Author";
            // 
            // bunifuCustomLabel3
            // 
            this.bunifuCustomLabel3.AutoSize = true;
            this.bunifuCustomLabel3.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.bunifuCustomLabel3.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel3.Location = new System.Drawing.Point(4, 169);
            this.bunifuCustomLabel3.Name = "bunifuCustomLabel3";
            this.bunifuCustomLabel3.Size = new System.Drawing.Size(117, 16);
            this.bunifuCustomLabel3.TabIndex = 8;
            this.bunifuCustomLabel3.Text = "Book Description";
            // 
            // bunifuCustomLabel4
            // 
            this.bunifuCustomLabel4.AutoSize = true;
            this.bunifuCustomLabel4.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.bunifuCustomLabel4.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel4.Location = new System.Drawing.Point(4, 248);
            this.bunifuCustomLabel4.Name = "bunifuCustomLabel4";
            this.bunifuCustomLabel4.Size = new System.Drawing.Size(115, 16);
            this.bunifuCustomLabel4.TabIndex = 9;
            this.bunifuCustomLabel4.Text = "Publication Date";
            // 
            // bunifuCustomLabel5
            // 
            this.bunifuCustomLabel5.AutoSize = true;
            this.bunifuCustomLabel5.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.bunifuCustomLabel5.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel5.Location = new System.Drawing.Point(4, 327);
            this.bunifuCustomLabel5.Name = "bunifuCustomLabel5";
            this.bunifuCustomLabel5.Size = new System.Drawing.Size(88, 16);
            this.bunifuCustomLabel5.TabIndex = 10;
            this.bunifuCustomLabel5.Text = "Print Length";
            // 
            // bunifuCustomLabel6
            // 
            this.bunifuCustomLabel6.AutoSize = true;
            this.bunifuCustomLabel6.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.bunifuCustomLabel6.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel6.Location = new System.Drawing.Point(190, 327);
            this.bunifuCustomLabel6.Name = "bunifuCustomLabel6";
            this.bunifuCustomLabel6.Size = new System.Drawing.Size(71, 16);
            this.bunifuCustomLabel6.TabIndex = 11;
            this.bunifuCustomLabel6.Text = "Language";
            // 
            // bunifuFlatButton1
            // 
            this.bunifuFlatButton1.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(237)))), ((int)(((byte)(59)))));
            this.bunifuFlatButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(32)))), ((int)(((byte)(40)))));
            this.bunifuFlatButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton1.BorderRadius = 0;
            this.bunifuFlatButton1.ButtonText = "Add";
            this.bunifuFlatButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton1.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton1.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton1.Iconimage = null;
            this.bunifuFlatButton1.Iconimage_right = null;
            this.bunifuFlatButton1.Iconimage_right_Selected = null;
            this.bunifuFlatButton1.Iconimage_Selected = null;
            this.bunifuFlatButton1.IconMarginLeft = 0;
            this.bunifuFlatButton1.IconMarginRight = 0;
            this.bunifuFlatButton1.IconRightVisible = true;
            this.bunifuFlatButton1.IconRightZoom = 0D;
            this.bunifuFlatButton1.IconVisible = true;
            this.bunifuFlatButton1.IconZoom = 90D;
            this.bunifuFlatButton1.IsTab = false;
            this.bunifuFlatButton1.Location = new System.Drawing.Point(67, 414);
            this.bunifuFlatButton1.Name = "bunifuFlatButton1";
            this.bunifuFlatButton1.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(32)))), ((int)(((byte)(40)))));
            this.bunifuFlatButton1.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(32)))), ((int)(((byte)(40)))));
            this.bunifuFlatButton1.OnHoverTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(237)))), ((int)(((byte)(59)))));
            this.bunifuFlatButton1.selected = false;
            this.bunifuFlatButton1.Size = new System.Drawing.Size(241, 48);
            this.bunifuFlatButton1.TabIndex = 6;
            this.bunifuFlatButton1.Text = "Add";
            this.bunifuFlatButton1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton1.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton1.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton1.Click += new System.EventHandler(this.bunifuFlatButton1_Click);
            // 
            // AddBook
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(46)))), ((int)(((byte)(59)))));
            this.Controls.Add(this.bunifuFlatButton1);
            this.Controls.Add(this.bunifuCustomLabel6);
            this.Controls.Add(this.bunifuCustomLabel5);
            this.Controls.Add(this.bunifuCustomLabel4);
            this.Controls.Add(this.bunifuCustomLabel3);
            this.Controls.Add(this.bunifuCustomLabel2);
            this.Controls.Add(this.bunifuCustomLabel1);
            this.Controls.Add(this.txtTitle);
            this.Controls.Add(this.txtAuthor);
            this.Controls.Add(this.txtDesc);
            this.Controls.Add(this.txtDate);
            this.Controls.Add(this.txtLen);
            this.Controls.Add(this.txtLan);
            this.Name = "AddBook";
            this.Size = new System.Drawing.Size(384, 483);
            this.Load += new System.EventHandler(this.AddBook_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuMetroTextbox txtLan;
        private Bunifu.Framework.UI.BunifuMetroTextbox txtLen;
        private Bunifu.Framework.UI.BunifuMetroTextbox txtDate;
        private Bunifu.Framework.UI.BunifuMetroTextbox txtDesc;
        private Bunifu.Framework.UI.BunifuMetroTextbox txtAuthor;
        private Bunifu.Framework.UI.BunifuMetroTextbox txtTitle;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel2;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel3;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel4;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel5;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel6;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton1;
    }
}
